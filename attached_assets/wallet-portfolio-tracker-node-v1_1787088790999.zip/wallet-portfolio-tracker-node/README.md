# Wallet Portfolio Tracker (Node.js)

A standalone, read-only wallet-first portfolio importer. Paste a public EVM or Solana address, assign a label, and keep all discovered holdings, snapshots, and balance-change events grouped under that wallet.

This package is intentionally separate from the VELVET AWS engine so it can be uploaded to Replit or integrated into another Node.js service.

## What it does

- Saves public wallet addresses under permanent user-defined labels.
- Discovers native coins, ERC-20 tokens, and SPL tokens.
- Supports Ethereum, BNB Chain, Base, Arbitrum, Polygon, Optimism, and Solana.
- Uses Alchemy Portfolio API for broad discovery.
- Optionally enriches Solana assets with Helius DAS.
- Verifies the highest-value EVM holdings directly with blockchain RPC.
- Reads SOL and SPL balances directly from Solana RPC.
- Stores balance snapshots and detects added, removed, increased, and decreased holdings.
- Separates recognized assets from unverified/dust assets.
- Exposes a dependency-free REST API.
- Uses no private keys and cannot send transactions.

## Replit setup

1. Upload this directory or its ZIP to a new Node.js Repl.
2. Add `ALCHEMY_API_KEY` as a Replit Secret.
3. Add a long random `TRACKER_API_KEY` if the Repl will be publicly reachable.
4. Optionally add `HELIUS_API_KEY` for stronger Solana coverage.
5. Run:

```bash
npm start
```

Node.js 20 or later is required. There are no npm runtime dependencies.

Copy `.env.example` values into Replit Secrets rather than committing API keys.

When `TRACKER_API_KEY` is set, every endpoint except `/healthz` requires either
`Authorization: Bearer <key>` or `x-api-key: <key>`.

## API

### Health and supported networks

```http
GET /healthz
GET /api/networks
```

### Import and label a wallet

```http
POST /api/wallets
Content-Type: application/json

{
  "address": "0x1111111111111111111111111111111111111111",
  "label": "Whale A",
  "networks": ["bnb-mainnet", "eth-mainnet", "base-mainnet"]
}
```

If `networks` is omitted, all compatible configured networks are scanned.

### Read, rename, refresh, or remove

```http
GET    /api/wallets
GET    /api/wallets/:id
PATCH  /api/wallets/:id
POST   /api/wallets/:id/refresh
DELETE /api/wallets/:id
```

Rename or change scanned networks:

```json
{
  "label": "Known Accumulator",
  "networks": ["bnb-mainnet", "base-mainnet"]
}
```

## Use as a module

```js
import { createWalletTracker } from "./src/index.js";

const { service, store } = createWalletTracker();

const wallet = await service.add({
  address: "0x1111111111111111111111111111111111111111",
  label: "Whale A",
  networks: ["bnb-mainnet"],
});

console.log(wallet.holdings);
console.log(await store.list());
```

## Stored data

The default JSON database is `data/wallets.json`. Each wallet contains:

- Its label, address, and selected networks
- Label provenance that explicitly distinguishes user organization from verified identity
- Current holdings
- Trust/spam classification
- Direct-verification status
- Portfolio value summary
- Up to 200 balance snapshots
- Up to 500 balance-change events
- Provider warnings and data provenance

Set `DATA_FILE` to another persistent path when integrating it into a larger service. The `JsonWalletStore` can also be replaced with a Postgres or other database adapter implementing `list`, `get`, `upsert`, and `remove`.

## Important limitations

- Portfolio prices are estimates and may be unavailable for obscure tokens.
- Indexed discovery can briefly lag the chain; material balances are therefore rechecked with RPC.
- A balance increase does not prove a purchase, and a decrease does not prove a sale. Transaction interpretation should be added from transfer history before using changes directionally.
- User labels are private organizational labels, not verified claims of identity.
- Alchemy supplies portfolio and transaction data; it is not treated as authoritative proof that an address is an exchange hot wallet, cold wallet, or proxy. Add a separately sourced identity provider or verified label registry for those claims.
- Never paste a seed phrase, private key, or exchange API secret into this service.

## Tests

```bash
npm test
```
