import http from "node:http";
import { createWalletTracker, SUPPORTED_NETWORKS } from "./index.js";

const tracker = createWalletTracker();
const { config, store, service } = tracker;

function send(response, status, payload) {
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-headers": "content-type",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
  });
  response.end(`${JSON.stringify(payload, null, 2)}\n`);
}

async function body(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 1_000_000) throw new Error("Request body is too large");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

const server = http.createServer(async (request, response) => {
  if (request.method === "OPTIONS") return send(response, 204, {});
  const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);
  const parts = url.pathname.split("/").filter(Boolean);
  try {
    if (request.method === "GET" && url.pathname === "/healthz") {
      return send(response, 200, {
        status: "ok",
        readOnly: true,
        walletCount: (await store.list()).length,
        supportedNetworks: Object.keys(SUPPORTED_NETWORKS),
        portfolioProviderConfigured: Boolean(config.alchemyApiKey),
        solanaEnrichmentConfigured: Boolean(config.heliusApiKey),
      });
    }
    if (config.trackerApiKey) {
      const bearer = String(request.headers.authorization || "").replace(/^Bearer\s+/i, "");
      const supplied = String(request.headers["x-api-key"] || bearer);
      if (supplied !== config.trackerApiKey) return send(response, 401, { error: "Unauthorized" });
    }
    if (request.method === "GET" && url.pathname === "/api/networks") {
      return send(response, 200, SUPPORTED_NETWORKS);
    }
    if (request.method === "GET" && url.pathname === "/api/wallets") {
      return send(response, 200, { wallets: await store.list() });
    }
    if (request.method === "POST" && url.pathname === "/api/wallets") {
      return send(response, 201, await service.add(await body(request)));
    }
    if (parts[0] === "api" && parts[1] === "wallets" && parts[2]) {
      const id = parts[2];
      if (request.method === "GET" && parts.length === 3) {
        const wallet = await store.get(id);
        return wallet ? send(response, 200, wallet) : send(response, 404, { error: "Wallet not found" });
      }
      if (request.method === "PATCH" && parts.length === 3) {
        return send(response, 200, await service.update(id, await body(request)));
      }
      if (request.method === "POST" && parts[3] === "refresh") {
        return send(response, 200, await service.refresh(id));
      }
      if (request.method === "DELETE" && parts.length === 3) {
        return send(response, (await store.remove(id)) ? 204 : 404, {});
      }
    }
    return send(response, 404, { error: "Route not found" });
  } catch (error) {
    const status = /not found/i.test(error.message) ? 404 : /valid|unsupported|already|JSON/i.test(error.message) ? 400 : 500;
    return send(response, status, { error: error.message });
  }
});

let refreshTimer;
if (config.refreshIntervalSeconds > 0) {
  refreshTimer = setInterval(() => {
    service.refreshAll().catch((error) => console.error("Background refresh failed:", error.message));
  }, config.refreshIntervalSeconds * 1000);
  refreshTimer.unref();
}

server.listen(config.port, config.host, () => {
  console.log(`Wallet portfolio tracker listening on http://${config.host}:${config.port}`);
});

function shutdown() {
  if (refreshTimer) clearInterval(refreshTimer);
  server.close(() => process.exit(0));
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
