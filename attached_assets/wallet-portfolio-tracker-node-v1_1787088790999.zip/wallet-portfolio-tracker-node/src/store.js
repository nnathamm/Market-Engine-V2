import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";

const EMPTY_DATABASE = { version: 1, wallets: [] };

export class JsonWalletStore {
  constructor(fileName) {
    this.fileName = path.resolve(fileName);
    this.queue = Promise.resolve();
  }

  async read() {
    try {
      const parsed = JSON.parse(await readFile(this.fileName, "utf8"));
      if (!Array.isArray(parsed.wallets)) throw new Error("wallets must be an array");
      return parsed;
    } catch (error) {
      if (error.code === "ENOENT") return structuredClone(EMPTY_DATABASE);
      throw error;
    }
  }

  async write(database) {
    this.queue = this.queue.then(async () => {
      await mkdir(path.dirname(this.fileName), { recursive: true });
      const temporary = `${this.fileName}.${process.pid}.tmp`;
      await writeFile(temporary, `${JSON.stringify(database, null, 2)}\n`, "utf8");
      await rename(temporary, this.fileName);
    });
    return this.queue;
  }

  async list() {
    return (await this.read()).wallets;
  }

  async get(id) {
    return (await this.list()).find((wallet) => wallet.id === id) || null;
  }

  async upsert(wallet) {
    const database = await this.read();
    const index = database.wallets.findIndex((item) => item.id === wallet.id);
    if (index >= 0) database.wallets[index] = wallet;
    else database.wallets.push(wallet);
    await this.write(database);
    return wallet;
  }

  async remove(id) {
    const database = await this.read();
    const before = database.wallets.length;
    database.wallets = database.wallets.filter((wallet) => wallet.id !== id);
    if (database.wallets.length === before) return false;
    await this.write(database);
    return true;
  }
}
