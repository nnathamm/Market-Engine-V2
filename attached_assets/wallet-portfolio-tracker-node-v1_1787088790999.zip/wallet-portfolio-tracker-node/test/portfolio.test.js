import test from "node:test";
import assert from "node:assert/strict";
import { WalletPortfolioService } from "../src/portfolio.js";

class MemoryStore {
  constructor() { this.wallets = []; }
  async list() { return structuredClone(this.wallets); }
  async get(id) { return structuredClone(this.wallets.find((item) => item.id === id) || null); }
  async upsert(wallet) {
    const index = this.wallets.findIndex((item) => item.id === wallet.id);
    if (index >= 0) this.wallets[index] = structuredClone(wallet);
    else this.wallets.push(structuredClone(wallet));
    return wallet;
  }
}

function service(store, balance = 100) {
  return new WalletPortfolioService({
    store,
    alchemy: {
      async tokensByWallet() {
        return [{
          network: "bnb-mainnet",
          contractAddress: "0x2222222222222222222222222222222222222222",
          isNative: false,
          name: "Test Token",
          symbol: "TEST",
          decimals: 18,
          balance,
          priceUsd: 2,
          valueUsd: balance * 2,
        }];
      },
    },
    helius: { async assetsByOwner() { return []; } },
    rpc: { async verifyEvm(_address, holding) { holding.balanceVerified = true; return holding; } },
    config: {
      rpcUrls: { "bnb-mainnet": "mock" },
      directVerifyLimit: 25,
      verifiedTokenRegistry: {},
      heliusApiKey: "",
    },
    clock: () => "2026-08-18T12:00:00.000Z",
  });
}

test("imports holdings and keeps them under the saved label", async () => {
  const store = new MemoryStore();
  const tracker = service(store);
  const wallet = await tracker.add({
    address: "0x1111111111111111111111111111111111111111",
    label: "Whale A",
    networks: ["bnb-mainnet"],
  });
  assert.equal(wallet.label, "Whale A");
  assert.equal(wallet.status, "LIVE");
  assert.equal(wallet.holdings[0].symbol, "TEST");
  assert.equal(wallet.holdings[0].balanceVerified, true);
  assert.equal(wallet.events[0].type, "TOKEN_ADDED");
  assert.equal(wallet.summary.totalValueUsd, 200);
});

test("records balance changes on later refreshes", async () => {
  const store = new MemoryStore();
  const tracker = service(store);
  const wallet = await tracker.add({
    address: "0x1111111111111111111111111111111111111111",
    label: "Whale A",
    networks: ["bnb-mainnet"],
  });
  tracker.alchemy.tokensByWallet = async () => [{
    ...wallet.holdings[0], balance: 70, valueUsd: 140,
  }];
  const updated = await tracker.refresh(wallet.id);
  assert.equal(updated.events[0].type, "BALANCE_DECREASED");
  assert.equal(updated.events[0].change, -30);
});
