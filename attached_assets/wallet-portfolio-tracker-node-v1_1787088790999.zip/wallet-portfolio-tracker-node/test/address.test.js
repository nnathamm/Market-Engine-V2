import test from "node:test";
import assert from "node:assert/strict";
import { addressType, normalizeAddress, normalizeNetworks } from "../src/address.js";

const EVM = "0x1111111111111111111111111111111111111111";
const SOL = "86xCnPeV69n6t3DnyGvkKobf9FdN2H9oiVDdaMpo2MMY";

test("validates and normalizes EVM addresses", () => {
  assert.equal(addressType(EVM), "evm");
  assert.equal(normalizeAddress(EVM.toUpperCase().replace("0X", "0x")), EVM);
  assert.ok(normalizeNetworks(EVM).includes("bnb-mainnet"));
});

test("keeps Solana addresses case-sensitive and rejects EVM networks", () => {
  assert.equal(addressType(SOL), "solana");
  assert.equal(normalizeAddress(SOL), SOL);
  assert.deepEqual(normalizeNetworks(SOL), ["sol-mainnet"]);
  assert.throws(() => normalizeNetworks(SOL, ["bnb-mainnet"]), /cannot be scanned/);
});
