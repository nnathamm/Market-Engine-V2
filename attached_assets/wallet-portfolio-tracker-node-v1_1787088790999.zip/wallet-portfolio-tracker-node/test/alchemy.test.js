import test from "node:test";
import assert from "node:assert/strict";
import { AlchemyPortfolioProvider } from "../src/providers/alchemy.js";

test("normalizes paginated Alchemy portfolio results", async () => {
  let calls = 0;
  const fetchImpl = async () => {
    calls += 1;
    return {
      ok: true,
      async json() {
        return {
          data: {
            tokens: [{
              network: "bnb-mainnet",
              tokenAddress: "0x2222222222222222222222222222222222222222",
              tokenBalance: calls === 1 ? "0xad78ebc5ac6200000" : "0x29a2241af62c0000",
              tokenMetadata: { name: calls === 1 ? "Alpha" : "Beta", symbol: calls === 1 ? "A" : "B", decimals: 18 },
              tokenPrices: [{ currency: "usd", value: "2" }],
            }],
            pageKey: calls === 1 ? "next" : null,
          },
        };
      },
    };
  };
  const provider = new AlchemyPortfolioProvider({ apiKey: "test", fetchImpl });
  const result = await provider.tokensByWallet("0x1111111111111111111111111111111111111111", ["bnb-mainnet"]);
  const tokens = result.tokens;
  assert.equal(calls, 2);
  assert.equal(tokens.length, 2);
  assert.equal(tokens[0].balance, 200);
  assert.equal(tokens[0].valueUsd, 400);
});
