# Stop Loss landing page

This package contains the standalone Stop Loss landing-page prototype.

## Run on Replit

1. Create or open a Replit Node.js project.
2. Upload and extract every file from the ZIP into the project root.
3. Press **Run**. The included configuration starts the site with `npm start`.

The page is self-contained and does not require API keys, a database, or npm dependencies.
